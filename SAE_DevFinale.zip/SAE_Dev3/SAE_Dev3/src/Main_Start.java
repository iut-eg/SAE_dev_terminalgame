public class
Main_Start {

    public static void main(String[] arg) {

        Interface.StartingPoint();

    }

}
